<?php
    require 'init.php';

    $sql = "select * from noticia";

    $result = mysqli_query($connection, $sql);
    $response = array();

    while($row = mysqli_fetch_array($result)){
        array_push($response, array('nomInstitucion'=>$row['nomInstitucion'],'fecha'=>$row['fecha']));
    }

    echo json_encode($response);

    mysqli_close($connection);
?>