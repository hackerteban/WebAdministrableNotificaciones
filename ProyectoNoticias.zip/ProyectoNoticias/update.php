<?php
	
	require 'conexion.php';

	$id = $_POST['id'];	
	$nomInstitucion = $_POST['nomInstitucion'];
	$fecha = $_POST['fecha'];
	$hora = $_POST['hora'];
	$tema = $_POST['tema'];
	$descripcion = $_POST['descripcion'];
    $imagen = addslashes(file_get_contents($_FILES['imagen']['tmp_name']));

	$sql = "UPDATE noticia SET nomInstitucion='$nomInstitucion', fecha='$fecha', hora='$hora', tema='$tema', descripcion='$descripcion', imagen='$imagen' WHERE id = '$id'";
	$resultado = $mysqli->query($sql);

    if($resultado){
        echo "Actualizo";
    }else{
        echo "No Actualizo";
    }
	
?>

<html lang="es">
	<head>
		
		<meta name="viewport" content="width=device-width, initial-scale=1">
		<link href="css/bootstrap.min.css" rel="stylesheet">
		<link href="css/bootstrap-theme.css" rel="stylesheet">
		<script src="js/jquery-3.1.1.min.js"></script>
		<script src="js/bootstrap.min.js"></script>	
	</head>
	
	<body>
		<div class="container">
			<div class="row">
				<div class="row" style="text-align:center">
				<?php if($resultado) { ?>
				<h3>REGISTRO MODIFICADO</h3>
				<?php } else { ?>
				<h3>ERROR AL MODIFICAR</h3>
				<?php } ?>
				
				<a href="index.php" class="btn btn-primary">Regresar</a>
				
				</div>
			</div>
		</div>
	</body>
</html>
