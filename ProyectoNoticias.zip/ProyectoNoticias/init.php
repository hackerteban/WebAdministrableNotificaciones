<?php
    $server = "localhost";
    $username = "root";
    $password = "";
    $database = "bdnoticia";

    $connection = mysqli_connect($server,$username, $password, $database);
?>


