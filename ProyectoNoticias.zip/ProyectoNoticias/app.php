<?php
    //$dato = $_POST['data'];
    echo "hola mundo desde php"; 
?>